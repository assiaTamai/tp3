package ma.fsr.ms.patientservice.service;

import ma.fsr.ms.patientservice.model.Patient;
import ma.fsr.ms.patientservice.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    public Patient getPatientById(Long id) {
        return patientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Patient introuvable: id " + id));
    }

    public Patient createPatient(Patient patient) {
        // Règles métier
        if (patient.getNom() == null || patient.getNom().isEmpty()) {
            throw new RuntimeException("Le nom du patient est obligatoire.");
        }
        if (patient.getTelephone() == null || patient.getTelephone().isEmpty()) {
            throw new RuntimeException("Le téléphone du patient est obligatoire.");
        }
        if (patient.getDateNaissance() != null && patient.getDateNaissance().isAfter(LocalDate.now())) {
            throw new RuntimeException("La date de naissance ne peut pas être future.");
        }

        return patientRepository.save(patient);
    }

}