package ma.fsr.ms.consultationservice.web;

import ma.fsr.ms.consultationservice.model.Consultation;
import ma.fsr.ms.consultationservice.service.ConsultationService;
import ma.fsr.ms.consultationservice.repository.ConsultationRepository; // Import nécessaire
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/internal/api/v1/consultations")
public class ConsultationController {

    @Autowired
    private ConsultationService consultationService;

    // INJECTION DU REPOSITORY
    @Autowired
    private ConsultationRepository consultationRepository;

    @GetMapping
    public List<Consultation> getAll() {
        return consultationService.getAll();
    }

    // VOICI LA CORRECTION ICI :
    @GetMapping("/rendezvous/{id}")
    public List<Consultation> getByRendezVousId(@PathVariable Long id) {
        // Utilisez la variable 'consultationRepository' (minuscule)
        return consultationRepository.findByRendezvousId(id);
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Consultation consultation) {
        try {
            return ResponseEntity.status(HttpStatus.CREATED).body(consultationService.createConsultation(consultation));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}