package ma.fsr.ms.consultationservice.service;

import ma.fsr.ms.consultationservice.client.RendezVousClient;
import ma.fsr.ms.consultationservice.model.Consultation;
import ma.fsr.ms.consultationservice.model.RendezVousDto;
import ma.fsr.ms.consultationservice.repository.ConsultationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ConsultationService {

    @Autowired
    private ConsultationRepository consultationRepository;

    @Autowired
    private RendezVousClient rendezVousClient;

    public List<Consultation> getAll() {
        return consultationRepository.findAll();
    }

    public Consultation createConsultation(Consultation consultation) {
        // 1. Vérifier si le RDV existe via Feign
        RendezVousDto rdv = null;
        try {
            rdv = rendezVousClient.getRendezVousById(consultation.getRendezvousId());
        } catch (Exception e) {
            throw new RuntimeException("Rendez-vous introuvable (id: " + consultation.getRendezvousId() + ")");
        }

        // 2. Vérifier rapport obligatoire
        if (consultation.getRapport() == null || consultation.getRapport().length() < 10) {
            throw new RuntimeException("Le rapport de consultation est obligatoire (min 10 car).");
        }

        // Optionnel : On pourrait vérifier que dateConsultation >= rdv.getDate()

        return consultationRepository.save(consultation);
    }
}