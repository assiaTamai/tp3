package ma.fsr.ms.consultationservice.model;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class RendezVousDto {
    private Long id;
    private LocalDateTime date;
    // On peut ajouter d'autres champs si nécessaire (statut, etc.)
}