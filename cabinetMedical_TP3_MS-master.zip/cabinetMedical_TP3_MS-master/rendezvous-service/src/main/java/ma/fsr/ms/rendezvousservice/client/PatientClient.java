package ma.fsr.ms.rendezvousservice.client;

import ma.fsr.ms.rendezvousservice.model.PatientDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

// "patient-service" est le nom déclaré dans application.properties de l'autre projet
@FeignClient(name = "patient-service", url = "${patient.service.url}")
public interface PatientClient {

    @GetMapping("/internal/api/v1/patients/{id}")
    PatientDto getPatientById(@PathVariable Long id);
}