package ma.fsr.ms.rendezvousservice.web;

import ma.fsr.ms.rendezvousservice.model.RendezVous;
import ma.fsr.ms.rendezvousservice.service.RendezVousService;
import ma.fsr.ms.rendezvousservice.repository.RendezVousRepository; // Import nécessaire
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/internal/api/v1/rendezvous")
public class RendezVousController {

    @Autowired
    private RendezVousService rendezVousService;

    // INJECTION DU REPOSITORY (Indispensable)
    @Autowired
    private RendezVousRepository rendezVousRepository;

    @GetMapping
    public List<RendezVous> getAll() {
        return rendezVousService.getAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<RendezVous> getById(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(rendezVousService.getRendezVousById(id));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // VOICI LA CORRECTION ICI :
    @GetMapping("/patient/{id}")
    public List<RendezVous> getByPatientId(@PathVariable Long id) {
        // Utilisez la variable 'rendezVousRepository' (minuscule), PAS la classe (Majuscule)
        return rendezVousRepository.findByPatientId(id);
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody RendezVous rdv) {
        try {
            return ResponseEntity.status(HttpStatus.CREATED).body(rendezVousService.createRendezVous(rdv));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}