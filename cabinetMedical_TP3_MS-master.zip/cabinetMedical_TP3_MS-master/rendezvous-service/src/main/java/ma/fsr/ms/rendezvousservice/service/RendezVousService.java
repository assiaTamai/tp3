package ma.fsr.ms.rendezvousservice.service;

import ma.fsr.ms.rendezvousservice.client.MedecinClient;
import ma.fsr.ms.rendezvousservice.client.PatientClient;
import ma.fsr.ms.rendezvousservice.model.RendezVous;
import ma.fsr.ms.rendezvousservice.model.StatutRdv;
import ma.fsr.ms.rendezvousservice.repository.RendezVousRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class RendezVousService {

    @Autowired
    private RendezVousRepository rendezVousRepository;

    // Injection des clients Feign
    @Autowired
    private PatientClient patientClient;
    @Autowired
    private MedecinClient medecinClient;

    public List<RendezVous> getAll() {
        return rendezVousRepository.findAll();
    }

    // Ajoutez ceci dans la classe RendezVousService
    public RendezVous getRendezVousById(Long id) {
        return rendezVousRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Rendez-vous introuvable"));
    }

    public RendezVous createRendezVous(RendezVous rdv) {
        // 1. Vérification de la date
        if (rdv.getDate() != null && rdv.getDate().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("La date du rendez-vous doit être future.");
        }

        // 2. Vérification existence Patient (Appel HTTP vers l'autre service)
        try {
            patientClient.getPatientById(rdv.getPatientId());
        } catch (Exception e) {
            throw new RuntimeException("Patient introuvable (id: " + rdv.getPatientId() + ")");
        }

        // 3. Vérification existence Médecin (Appel HTTP vers l'autre service)
        try {
            medecinClient.getMedecinById(rdv.getMedecinId());
        } catch (Exception e) {
            throw new RuntimeException("Médecin introuvable (id: " + rdv.getMedecinId() + ")");
        }



        // 4. Initialisation du statut
        rdv.setStatut(StatutRdv.PLANIFIE);

        return rendezVousRepository.save(rdv);
    }
}