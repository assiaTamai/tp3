package ma.fsr.ms.rendezvousservice.repository;

import ma.fsr.ms.rendezvousservice.model.RendezVous;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface RendezVousRepository extends JpaRepository<RendezVous, Long> {

    // CORRECTION : Pas de static, pas d'accolades, juste un point-virgule.
    List<RendezVous> findByPatientId(Long patientId);

}