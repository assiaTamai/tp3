package ma.fsr.ms.rendezvousservice.model;
import lombok.Data;

@Data
public class MedecinDto {
    private Long id;
    private String nom;
    private String specialite;
}