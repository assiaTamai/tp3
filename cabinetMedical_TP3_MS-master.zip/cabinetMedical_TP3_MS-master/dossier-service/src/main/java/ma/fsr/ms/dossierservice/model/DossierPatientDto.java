package ma.fsr.ms.dossierservice.model;

import lombok.Data;
import java.util.List;

@Data
public class DossierPatientDto {
    private Long patientId;
    private String nomPatient;
    private String email;
    private List<RendezVousFullDto> historiqueRendezVous;
}