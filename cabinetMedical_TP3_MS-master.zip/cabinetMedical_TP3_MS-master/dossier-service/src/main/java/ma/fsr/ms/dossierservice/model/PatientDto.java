package ma.fsr.ms.dossierservice.model;

import lombok.Data;
import java.time.LocalDate;

@Data
public class PatientDto {
    private Long id;
    private String nom;
    private String email;
    private String telephone;
    private LocalDate dateNaissance;
}