package ma.fsr.ms.dossierservice.model;

import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class RendezVousFullDto {
    private Long id;
    private LocalDateTime date;
    private String statut;
    private Long medecinId;
    private List<ConsultationDto> consultations; // La liste imbriquée
}