package ma.fsr.ms.dossierservice.web;

import ma.fsr.ms.dossierservice.model.DossierPatientDto;
import ma.fsr.ms.dossierservice.service.DossierService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/internal/api/v1/dossiers")
public class DossierController {

    @Autowired
    private DossierService dossierService;

    @GetMapping("/patient/{id}")
    public DossierPatientDto getDossierPatient(@PathVariable Long id) {
        return dossierService.getDossier(id);
    }
}