package ma.fsr.ms.dossierservice.client;

import ma.fsr.ms.dossierservice.model.RendezVousDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import java.util.List;

@FeignClient(name = "rendezvous-service", url = "${rendezvous.service.url}")
public interface RendezVousClient {
    // Note : Cette route doit exister dans rendezvous-service (ajoutée à l'étape précédente)
    @GetMapping("/internal/api/v1/rendezvous/patient/{id}")
    List<RendezVousDto> getRendezVousByPatient(@PathVariable Long id);
}