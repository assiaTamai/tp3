package ma.fsr.ms.dossierservice.client;

import ma.fsr.ms.dossierservice.model.ConsultationDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import java.util.List;

@FeignClient(name = "consultation-service", url = "${consultation.service.url}")
public interface ConsultationClient {
    // Note : Cette route doit exister dans consultation-service (ajoutée à l'étape précédente)
    @GetMapping("/internal/api/v1/consultations/rendezvous/{id}")
    List<ConsultationDto> getConsultationsByRendezVous(@PathVariable Long id);
}