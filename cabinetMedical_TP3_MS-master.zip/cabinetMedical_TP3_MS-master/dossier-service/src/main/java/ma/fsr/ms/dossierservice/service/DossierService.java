package ma.fsr.ms.dossierservice.service;

import ma.fsr.ms.dossierservice.client.ConsultationClient;
import ma.fsr.ms.dossierservice.client.PatientClient;
import ma.fsr.ms.dossierservice.client.RendezVousClient;
import ma.fsr.ms.dossierservice.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DossierService {

    @Autowired
    private PatientClient patientClient;
    @Autowired
    private RendezVousClient rdvClient;
    @Autowired
    private ConsultationClient consultationClient;

    public DossierPatientDto getDossier(Long patientId) {
        // 1. Récupérer les infos du Patient
        PatientDto patient = patientClient.getPatient(patientId);

        // 2. Initialiser le Dossier
        DossierPatientDto dossier = new DossierPatientDto();
        dossier.setPatientId(patient.getId());
        dossier.setNomPatient(patient.getNom());
        dossier.setEmail(patient.getEmail());

        // 3. Récupérer tous les RDVs du patient
        List<RendezVousDto> rdvs = rdvClient.getRendezVousByPatient(patientId);

        // 4. Pour chaque RDV, aller chercher ses consultations et transformer en RendezVousFullDto
        List<RendezVousFullDto> rdvsComplets = rdvs.stream().map(rdv -> {
            RendezVousFullDto complet = new RendezVousFullDto();
            complet.setId(rdv.getId());
            complet.setDate(rdv.getDate());
            complet.setStatut(rdv.getStatut());
            complet.setMedecinId(rdv.getMedecinId());

            // Appel au service Consultation pour ce RDV spécifique
            List<ConsultationDto> consults = consultationClient.getConsultationsByRendezVous(rdv.getId());
            complet.setConsultations(consults);

            return complet;
        }).collect(Collectors.toList());

        // 5. Ajouter la liste enrichie au dossier
        dossier.setHistoriqueRendezVous(rdvsComplets);

        return dossier;
    }
}