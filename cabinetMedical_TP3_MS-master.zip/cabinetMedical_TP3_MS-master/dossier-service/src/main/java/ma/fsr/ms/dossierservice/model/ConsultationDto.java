package ma.fsr.ms.dossierservice.model;

import lombok.Data;
import java.time.LocalDate;

@Data
public class ConsultationDto {
    private Long id;
    private LocalDate dateConsultation;
    private String rapport;
}