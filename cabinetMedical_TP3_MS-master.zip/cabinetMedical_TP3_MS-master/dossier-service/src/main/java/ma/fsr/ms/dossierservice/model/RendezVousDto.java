package ma.fsr.ms.dossierservice.model;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class RendezVousDto {
    private Long id;
    private LocalDateTime date;
    private String statut;
    private Long medecinId;
    private Long patientId;
}