package ma.fsr.ms.medecinservice.web;

import ma.fsr.ms.medecinservice.model.Medecin;
import ma.fsr.ms.medecinservice.service.MedecinService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/internal/api/v1/medecins")
public class MedecinController {

    @Autowired
    private MedecinService medecinService;

    @GetMapping
    public List<Medecin> getAll() {
        return medecinService.getAllMedecins();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Medecin> getById(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(medecinService.getMedecinById(id));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Medecin medecin) {
        try {
            return ResponseEntity.status(HttpStatus.CREATED).body(medecinService.createMedecin(medecin));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}