package ma.fsr.ms.medecinservice.service;

import ma.fsr.ms.medecinservice.model.Medecin;
import ma.fsr.ms.medecinservice.repository.MedecinRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MedecinService {

    @Autowired
    private MedecinRepository medecinRepository;

    public List<Medecin> getAllMedecins() {
        return medecinRepository.findAll();
    }

    public Medecin getMedecinById(Long id) {
        return medecinRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Médecin introuvable: id " + id));
    }

    public Medecin createMedecin(Medecin medecin) {
        // Règles métier
        if (medecin.getNom() == null || medecin.getNom().isEmpty()) {
            throw new RuntimeException("Le nom du médecin est obligatoire.");
        }
        if (medecin.getEmail() == null || medecin.getEmail().isEmpty()) {
            throw new RuntimeException("L'email du médecin est obligatoire.");
        }
        if (!medecin.getEmail().contains("@")) {
            throw new RuntimeException("Email du médecin invalide.");
        }
        if (medecin.getSpecialite() == null || medecin.getSpecialite().isEmpty()) {
            throw new RuntimeException("La spécialité du médecin est obligatoire.");
        }

        return medecinRepository.save(medecin);
    }
}